"""Independent offline consistency check; no transports or account access."""
from collections import Counter
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/dea425996b77')
TREE = '199906b53672ea35b06543ea6a5ebc5b38647972'
SHA = 'a6787c87ddfbb527f2b89da035ccb00b5fb8a8b1'
WORKTREE = ROOT / 'frozen-production-review-12b6fa2'
sys.path.insert(0, str(WORKTREE))
from polymarket_scanner.production.exchange import validate_buy_minimum
from polymarket_scanner.production.fees import fee_requirement
from tools.production_public_execution_probe import policy_result

evidence = ROOT / 'production-evidence'
files = ['ci-a678-execution-public-probe.json', 'ci-a678-live-sources.json',
         'ci-a678-semantic-census.json', 'ci-a678-run-results.json']
public, sources, census, runs = [json.loads((evidence / f).read_text()) for f in files]
for ref in ('HEAD', SHA):
    actual = subprocess.check_output(['git', 'rev-parse', ref + '^{tree}'],
                                     cwd=WORKTREE, text=True).strip()
    assert actual == TREE, (ref, actual)
assert public['git_sha'] == SHA
assert public['status'] == 'PUBLIC_MARKET_FEE_POLICY_VERIFIED'
assert public['authenticated_calls'] == public['financial_mutations'] == 0
assert public['account_host_weather_edge_and_operator_limits_verified'] is False
assert public['scope'] == 'BOUNDED_STRICT_WEATHER_PUBLIC_MARKET_FEE_SAMPLE'
assert public['sample_discovery_truncated'] is True
attempts = public['market_attempts']
assert len(attempts) == len({a['event_id'] for a in attempts}) == 5
assert all(a['reason'] == 'BOOK_STALE' for a in attempts[:-1])
success = attempts[-1]
assert success['status'] == public['status']
assert success['event_id'] == '1021464'
fee = success['fee_evidence']
snapshot = dict(success, max_fee_bps=fee['max_fee_bps'], fee_policy=fee['policy'])
assert fee_requirement(snapshot, success['fee_check_buy_limit'], False) == Decimal('.0250')
for policy, expected in success['fee_policies'].items():
    assert policy_result(snapshot, success['fee_check_buy_limit'], policy) == expected
assert fee['maker_base_fee_bps'] == fee['taker_base_fee_bps'] == 1000
assert fee['fd'] == {'r': .05, 'e': 1, 'to': True}
assert fee['max_fee_bps'] == 0
assert success['fee_policies']['ONCHAIN_BOUND'] == {
    'supported': False, 'reason': 'UNBOUNDED_EXCHANGE_FEE'}
validate_buy_minimum(success, success['quoted_depth'], success['quote_price_for_minimum_size'])
assert 0 <= success['received_at'] - success['book_timestamp'] < 15
assert 0 <= success['received_at'] - fee['max_fee_block']['timestamp'] < 180
identity = dict(success['strict_contract'])
digest = identity.pop('sha256')
assert sha256(json.dumps(identity, sort_keys=True, separators=(',', ':'),
                         ensure_ascii=True).encode()).hexdigest() == digest
assert identity['event_id'] == success['event_id']
assert identity['station'] == 'KDAL' and identity['unit'] == 'F'
assert identity['target_date'] == '2026-09-16'
assert identity['version'] == 'weather_contract_strict_v9_reviewed_city_station_binding'
assert len(identity['questions']) == 11
for provider in public['providers']:
    if provider['status'] == 'PUBLIC_READ_VERIFIED':
        assert len(provider['maximum_fee_bps']) == 2
        assert set(provider['maximum_fee_bps'].values()) == {0}
        assert provider['zero_maximum_means'] == 'NO_ONCHAIN_FEE_BOUND_NOT_ZERO_FEE'

assert sources['checks'] and all(x is True for x in sources['checks'].values())
assert sources['financial_authority'] is sources['same_day_delivery_enabled'] is False
assert sources['browser_token_persisted'] is sources['raw_provider_payload_persisted'] is False
assert sources['station'] == 'KSEA' and sources['target_date'] == '2026-09-16'
assert sources['wrh_target_row_count'] == sources['wrh_temperature_count'] == 15
assert sources['gefs_member_count'] == 31 and sources['gefs_valid_time_count'] == 24

ledger = census['semantic_event_ledger']
counts = Counter(x['classification'] for x in ledger)
assert len(ledger) == len({x['event_id'] for x in ledger}) == 338
assert counts.pop('SUPPORTED') == census['strict_supported_events'] == 78
assert dict(counts) == census['unsupported_reason_counts']
assert sum(counts.values()) == census['unsupported_weather_events'] == 260
assert census['weather_looking_events'] == 78 + 260
assert census['scanned_events'] == census['total_active_events_scanned'] == 21074
assert census['pages'] == 422 and census['retained_events'] == 78
assert census['complete'] is census['gamma_census_complete'] is True
assert census['weather_semantic_coverage_complete'] is False
assert census['weather_semantic_coverage_status'] == 'PARTIAL_STRICT_SUBSET'
assert census['weather_semantic_product_policy'] == 'STRICT_SUPPORTED_SUBSET'
assert next(x for x in ledger if x['event_id'] == success['event_id'])['classification'] == 'SUPPORTED'

assert len(runs) == 5 and all(r['sha'] == SHA and r['conclusion'] == 'success' for r in runs)
assert {r['id'] for r in runs} == {35152180297, 35152176666, 35152176836, 35152176605, 35152176555}
test_jobs = {'104982908809': '53.94', '104982908476': '55.99'}
for job, seconds in test_jobs.items():
    log = (evidence / ('ci-a678-test-' + job + '.log')).read_text()
    assert SHA in log and f'1865 passed, 4 warnings in {seconds}s' in log
    assert '"scope": "SYNTHETIC_OFFLINE_CAPACITY_NOT_E2_MICRO_LIVE_VALIDATION"' in log
    assert '"passed": true' in log

print(json.dumps({
    'status': 'PASS_OFFLINE_SAVED_EVIDENCE_CONSISTENCY', 'git_sha': SHA, 'tree': TREE,
    'public_event': success['event_id'], 'public_attempts_distinct_events': len(attempts),
    'published_fee_per_share_recomputed': str(fee_requirement(snapshot, '.94', False)),
    'strict_onchain_zero_rejected': True, 'fee_identity_digest_verified': True,
    'strict_contract_digest_verified': True, 'all_source_checks_true': len(sources['checks']),
    'census_supported': 78, 'census_rejected': 260, 'ci_runs_success': len(runs),
    'ci_tests_per_python': 1865, 'ci_scale_is_synthetic': True,
    'new_network_calls': 0,
    'artifact_sha256': {f: sha256((evidence / f).read_bytes()).hexdigest() for f in files},
}, indent=2, sort_keys=True))
