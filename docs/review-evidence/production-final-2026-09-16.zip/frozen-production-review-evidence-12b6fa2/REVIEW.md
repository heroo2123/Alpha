# Independent corrected production freeze review

Commit: `12b6fa2a925eddc0817bf44d319427b427bdabc6`.
Tree: `199906b53672ea35b06543ea6a5ebc5b38647972`.
Detached worktree: `/workspace/scratch/dea425996b77/frozen-production-review-12b6fa2`.

Disposition: **PASS for the independently reviewed code scope, conditional on
matching exact-tree CI and a successful real public execution probe.** This is
not authorization to activate production, access a funded account, or certify a
target host. No additional unresolved code blocker was demonstrated in this
freeze. The failed earlier public probe remains historical failure evidence.

## Reviewed corrections and conclusions

The prior frozen review at `51d66c9` traced the canonical production CLI,
signals/execution/preflight/recover paths, weather semantics, financial adapter,
chain receipts, order ledger, active dispatch and host authority. This review
retains that scope and independently reviews every code change through the new
freeze, including the intermediate `dfb1a945` cumulative-limit correction.
Host trust, source-finality rules, signal delivery, strict weather semantics and
canonical dispatch implementations are unchanged by this final delta.

1. **Published fee metadata:** Nonzero `mbf`/`tbf` no longer cause the invented
   zero-only rejection. Raw fields remain durable evidence with bounded int64
   validation. The official SDK's `MarketInfo` and `_parse_platform_fee_info`
   use `fd.r`/`fd.e`; its BUY budgeting formula adds that curve and a separately
   selected builder fee. The bot signs a zero builder identifier. This matches
   the explicitly selected SDK/published-schedule policy without claiming an
   immutable or signed fee ceiling. Missing/unsupported curve evidence still
   fails closed. The strict positive onchain-bound policy still rejects zero.
2. **Sample/probe fidelity:** The credential-free reader is still shared with
   the live adapter. Public diagnostics now retain bounded fee fields even when
   books are stale or schema validation fails. Bounded discovery precedes book
   sampling; one event cannot monopolize the entire attempt budget before later
   supported events are examined. The result remains a sample, not a census or
   proof of account eligibility, profitability, or an executable weather edge.
3. **Minimum-size ambiguity:** The documented conservative policy requires
   both share quantity and submitted BUY notional to meet the API minimum,
   including maker GTD. The adapter and public quote probe share the helper;
   the engine rejects insufficient notional before reserving. It does not raise
   an operator budget to meet a minimum. Small partial fills remain valid
   accounting evidence. The policy is explicitly described as a supported
   subset rather than an assertion that the venue enforces both units.
4. **Aggregate actual limits:** Per-fill checks remain, and cumulative order
   quantity/cost/fees prevent one-micro tolerances accumulating without a fault.
   Actual evidence, fault and all-managed remainder cancellation work share a
   transaction. No actual fill is erased to fit a reservation or estimate.
5. **Existing-journal upgrade:** A versioned audit runs before reconciliation
   can grant authority. It checks all recorded order totals and atomically
   commits breach evidence, a sticky fault, managed cancellation work and its
   completion marker. The independently reproduced duplicate-only upgrade gap
   is fixed. A crash after the marker but before cancellation does not discard
   queued work. Keeping the marker after explicit recovery avoids repeatedly
   reviving an acknowledged historical breach. New late fills remain checked
   and can fault/cancel other managed orders after that recovery.

## Verification

The frozen worktree passed **374 scoped cases on each Python version**:

- Python 3.11: 374 passed, 23.30 s.
- Python 3.12: 374 passed, 24.48 s.

Scope includes `tests/test_production*.py`, retained frozen regressions,
host-authority production boundaries, weather production-review regressions,
four additional aggregate/restart/atomicity cases, two additional upgrade
crash/recovery/late-fill cases, and the formerly failing existing-journal
reproduction. The original eleven independent fee cases are now retained as
`tests/test_production_frozen_fee_review.py`; an exact comparison showed only
the stated real-adapter test fixture's explicit per-order budget change from 5
to 6, allowing it to meet the newly stated minimum plus fees. No safety
assertions were weakened.

The additional independent sources remain in the sibling evidence directory
`frozen-production-review-evidence-dfb1a94` as
`test_independent_aggregate.py`, `test_independent_upgrade.py` and
`repro_preexisting_journal.py`. The latter uses frozen-51 ledger code to create
an authentic old-code journal; its setup removes the current fixture's initial
audit marker because the old release could not have created that marker.

All network mutations in the scoped tests are mocked. Actual chain-event ABI
decoding and the real adapter/engine/SQLite path are exercised using synthetic
inputs. No production worktree modifications were made; the detached candidate
remained clean at the stated SHA/tree.

## Source verification

The inspected official SDK wheel SHA-256 independently matches
`f378e07351d4bfdf390ca84c6ba47898f9a715f2f4446afe0446bbeafa495ee5`.
Its `_internal/actions/orders/market.py` and `market_data.py` support the stated
fee calculation and metadata interpretation. This is source inspection, not
installation of the SDK in the production runtime.

The [official fees documentation](https://docs.polymarket.com/trading/fees)
supports the maker exemption and published five-decimal/subminimum rounding
convention. The [market-info schema](https://docs.polymarket.com/api-reference/markets/get-clob-market-info)
exposes base-fee metadata and the separate fee curve. The
[market-details trading constraints](https://docs.polymarket.com/market-data/market-details#trading-constraints)
explicitly label the minimum as USDC notional. The implementation qualifies the
remaining unit ambiguity and does not claim cancellation latency from `oas`.

## Remaining gates and limits

A passing exact-tree public CI probe is still required to replace the failed
earlier public-readiness result. The code review does not manufacture that
result from mocked fixtures. Any later code delta requires review; a docs-only
descendant can be checked against this exact tree before carrying the approval.

No production host, services, database, Telegram account, credentials, funded
account, real submitted order, or onchain financial mutation was accessed.
Independent host provisioning/approval, actual account identity/exclusivity,
funding, allowances, regional eligibility, activation and target resource
acceptance remain separate operator gates. Published fees remain mutable venue
policy; local submission limits and full fee reservation do not bind future
exchange matching or erase losses. Supported strategy/contract scope remains
strict; unproved result-lag finality is rejected and forecast support remains
uncalibrated. Settlement claim value, verified redemption cash and native gas
continue to be reported separately.

## Exact-tree public evidence closure, 2026-09-16

**The matching-tree CI and successful public-probe conditions stated above are
now CLOSED. Current disposition: PASS for the reviewed code and observed public
integration scope.** The initial conditional assessment remains intact as
review history. The earlier failed `b839`/frozen-51 result is not relabeled.

Independently verified that remote candidate
`a6787c87ddfbb527f2b89da035ccb00b5fb8a8b1` and frozen `12b6fa2` both have tree
`199906b53672ea35b06543ea6a5ebc5b38647972`. The saved run metadata reports all
five runs successful at that exact remote SHA: public execution probe
`35152176605`, live sources `35152176555`, semantic census `35152176666`, push
tests `35152176836`, and PR tests `35152180297`. The two saved Python job logs
show **1,865 tests passed each**, with 53.94 s for Python 3.11 and 55.99 s for
Python 3.12. Both also pass the explicitly synthetic scale check; that result
does not certify production-host resources.

Inspected the complete saved public probe JSON rather than just its success
label. Five attempts cover five distinct events; four stale books remain
explicit normal-input failures and the fifth, strict Dallas/KDAL event
`1021464`, supplies a fresh 0.94 BUY quote with depth 87 and the conservative
minimum 5 shares/5 notional. Real public metadata is `mbf=1000`, `tbf=1000`,
`fd={r:0.05,e:1,to:true}`. Both approved exchanges return `maximumFee=0`.
Offline re-evaluation using the reviewed production fee function reproduces
the published-schedule requirement of **0.0250 collateral per share** and the
strict `ONCHAIN_BOUND` rejection `UNBOUNDED_EXCHANGE_FEE`. The fee evidence
digest and strict contract digest verify, identities agree, and the recorded
book/chain timestamps satisfy the checked freshness windows at observation.
The artifact reports zero authenticated calls and zero financial mutations.

The source artifact has all 25 checks true, 15 KSEA WRH rows/temperatures and
31 GEFS members with 24 valid times, with no financial or same-day-delivery
authority. Independently counted the census ledger: 338 unique weather-looking
events, 78 supported and 260 explicitly rejected, within 21,074 events over
422 pages. The sampled execution event is supported in that ledger. Full Gamma
walk completion and partial strict semantic coverage are separately and
accurately labeled. Source and census artifacts do not themselves embed a Git
SHA; their exact-SHA provenance is supplied by the saved workflow run metadata.

The independent offline artifact validator and its compact output are retained
as `validate_saved_public_evidence.py` and
`saved-public-evidence-verification.json`, including artifact SHA-256 hashes.
It performed no new network calls. Source artifacts are preserved under
`../production-evidence/ci-a678-*` in the workspace, including both complete CI
test logs and run metadata. No redundant full suite was run for this closure.

These observations close the demonstrated public fee/schema blocker. They
remain a dated, bounded public sample and separate public source/census checks,
not proof of future quote availability, weather edge, finality for every
contract, account eligibility, host approval or a signed fee ceiling. The
operator and activation gates above continue to apply. A subsequent docs-only
freeze still requires the promised final delta check before carrying this
assessment forward.
