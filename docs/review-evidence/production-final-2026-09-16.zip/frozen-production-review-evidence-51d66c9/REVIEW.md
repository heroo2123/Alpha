# Independent frozen production review: 51d66c9

Reviewed commit: `51d66c9cc42ad9efb23ccd41a6a1ed3972dbe873`.
Reviewed Git tree: `bba801b95c347468d9921a1ad9b3d1a8545a6ac0`.
Detached worktree: `/workspace/scratch/dea425996b77/frozen-production-review-51d66c9`.

Disposition: **NOT APPROVED for readiness at this freeze.** Local adversarial
checks found no additional demonstrated financial-accounting defect, but the
exact-code public execution probe failed. A corrective candidate and fresh
independent delta review are required. This is not deployment/host/account
acceptance.

## Confirmed blocker

`production/fees.py` rejects every nonzero `maker_base_fee_bps` or
`taker_base_fee_bps` as `BASE_FEE_COMPOSITION_UNSUPPORTED`. The parent-provided
exact-tree public probe record for remote `b8394f3febd7bf7845fc0006ff5419a25780816a`
contains four fresh market attempts rejected for this reason. Eight other
attempts had stale books; all twelve were from event `1020939`. The sample then
failed `PUBLIC_MARKET_SAMPLE_ATTEMPT_CAP`.

The fresh-market failures prevent a claim that the new policy works against
current public venue inputs. They must not be waived on the strength of the
zero-base-fee fixture suite. The public report does not retain the rejected raw
fee values, so the exact interpretation/composition of these fields requires
fresh public evidence and official-source inspection before changing admission.
Stale/missing quotes remain normal opportunity skips, never invented inputs.

Public record inspected:
`/workspace/scratch/dea425996b77/production-evidence/ci-b839-execution-public-probe.json`.

## Independent checks

- 321 targeted repository tests passed on Python 3.11 (21.06 s) and 3.12
  (26.63 s): `tests/test_production*.py`, `tests/test_frozen_production_review.py`,
  and `tests/test_host_authority_production_boundary.py`.
- 11 additional independent cases in `test_independent_51d66c9.py` passed on
  each version. They cover the published-envelope fee bound across prices and
  fragmented quantization, stale fee reads, a full first-leg fee breach stopping
  the rest of a basket and cancelling another intent, a submission-evidence
  audit-write failure preventing POST, failed cancellation across restart and
  recovery, full remaining fee reservation, and the real adapter's lost-response
  path followed by decoded chain partial-fill fee breach and immediate mocked
  cancellation.
- 14 retained weather production-review regressions passed on each version.
  The 3.12 independent/weather combined run has 25 passes.
- Total unique scoped cases: 346 per Python version. The separate retained
  frozen regressions are included in the 321, not double-counted.
- The detached worktree remained clean; no production files were edited.
- One initial independent test collection command had a local pytest
  `pythonpath` option typo. It is preserved in `harness-import-setup-error.log`;
  no product assertion failed. Correcting the harness path collected all cases.

## Paths and boundaries inspected

The checkpoint, execution API policy, operations, host-trust documentation,
README and configuration example were treated as claims. Traced the canonical
CLI through `production/__main__.py`, `config.py`, `engine.py`, `ledger.py`,
`exchange.py`, `chain.py`, `fees.py`, `weather.py`, `signals.py`, `service.py`,
`telegram.py`, and the related legacy-cutover tests. Reviewed the corrective
diff from `c77a3455e96f9e2b8319508ed03528ae3c6af1e8`, including shared
`PublicMarketReader`, `tools/production_public_execution_probe.py`, fee and
opening-eligibility regressions, and CI fixture/workflow changes.

Reviewed strict weather city/station/rule binding and source-finality behavior
in `weather_only_contract_strict.py`, `weather_only_rules.py`,
`weather_only_result_lag.py`, `weather_only_clob.py`, the composed production
weather path, and retained weather regressions. Unsupported templates and
unproved first-publication finality remain explicit rejections.

Reviewed active host dispatch in `deploy/production-host-control.sh`, component
configuration/UID/state-directory binding, process environment verification,
and unchanged-journal-only recovery in
`host_trust/weather-paper-authority-v3/authority.py`. The corrective diff does
not change the host authority or deployment implementation. Fixture corrections
retain separate real-admission, nonroot-owner and extra-group negative tests.

The lifecycle preserves durable intent before one POST, unknown-submission
reservation with no blind replay, exact confirmed fill accounting, all-managed
remainder cancellation after actual breaches, full operator fee reserve in
published-schedule mode, and separation of settlement claim value from verified
redemption cash and native gas. Opening eligibility is distinct from successful
read reconciliation, and explicit preflight rejects close-only eligibility.

## Fee-source assessment

Inspected the supplied official `polymarket-client` 0.10.0 source at
`execution-sdk/source/polymarket/_internal/actions/orders/market.py` and
`market_data.py`: BUY budgeting uses shares times `fd.r * (p * (1-p)) ** fd.e`,
plus an explicitly selected builder fee. Its fee parser does not consume
`mbf`/`tbf`; that observation alone is not proof of all venue compositions.

The current [official fees documentation](https://docs.polymarket.com/trading/fees)
confirms maker exemption and five-decimal fee precision with subminimum fees
rounded to zero. The code's factor-two envelope covers those rounding cases
over every BUY fill price no greater than the limit; independent grid/fragment
checks passed. The [market-info schema](https://docs.polymarket.com/api-reference/markets/get-clob-market-info)
labels `mbf`/`tbf` as base-fee basis points and separately exposes `fd`, without
an explicit composition rule in the inspected text. Source claims must remain
qualified until the corrective investigation resolves the observed nonzero data.

## Residual scope

No production host, services, databases, Telegram account, private credentials,
funded account, real signing submission or financial mutation was accessed.
Authenticated network operations were mocked. Public source documentation was
read; the live probe evidence came from the parent's read-only CI run.
Target-host provisioning, actual account eligibility/exclusivity, credentials,
funding, allowances, independent host approvals, and target e2-micro acceptance
remain operator gates. The schedule remains a mutable venue assumption rather
than a signed or immutable exchange fee ceiling. Local tests do not certify
those gates or financial returns.
