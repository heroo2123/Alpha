"""Independent aggregate limit/restart/atomicity review of dfb1a945."""
import asyncio
from decimal import Decimal
import importlib.util
from pathlib import Path
import sqlite3

import pytest

from polymarket_scanner.production.ledger import ExecutionLedger
from test_production_lifecycle import harness


def fragment(order, index, quantity, cost, fee):
    return {"id": f"review:{index}", "order_id": order["id"], "token": order["token"],
            "quantity": quantity, "cost": cost, "fee": fee,
            "transaction_hash": f"review-tx-{index}", "block_hash": "review-block",
            "log_index": index}


@pytest.mark.parametrize("cost,fee,code", [(4, 1, "ACTUAL_FEE_LIMIT_BREACH"),
                                         (5, 0, "ACTUAL_PRICE_LIMIT_BREACH")])
def test_fragment_limit_survives_restart_and_cancel_queue_write_failure(harness, cost, fee, code):
    cfg, signal, store, ledger, exchange, weather, engine = harness
    assert asyncio.run(engine.execute(signal))
    order = ledger.orders()[0]
    first, second = [fragment(order, index, 10, cost, fee) for index in range(2)]
    assert ledger.record_fill(first)
    ledger = ExecutionLedger(cfg.execution_db, cfg.wallet)
    ledger.recover_after_restart()
    assert ledger.state("fault") is None
    before = ledger.order(order["id"])
    with ledger.connect() as db:
        db.execute("CREATE TRIGGER aggregate_write_fault BEFORE INSERT ON execution_audit WHEN NEW.kind='ACTUAL_LIMIT_BREACH_CANCEL_QUEUED' BEGIN SELECT RAISE(ABORT,'independent injected failure'); END")
    with pytest.raises(sqlite3.Error):
        ledger.record_fill(second)
    assert ledger.order(order["id"]) == before
    assert ledger.state("fault") is None
    assert ledger.summary()["confirmed_fill_count"] == 1
    with ledger.connect() as db:
        db.execute("DROP TRIGGER aggregate_write_fault")
    assert ledger.record_fill(second)
    assert ledger.state("fault") == code
    assert ledger.summary()["confirmed_fill_count"] == 2
    assert ledger.order(order["id"])["status"] == "CANCEL_REQUESTED"
    assert not ledger.record_fill(second)
    assert ledger.summary()["confirmed_fill_count"] == 2


@pytest.mark.parametrize("cost,fee,code", [(4, 2, "ACTUAL_FEE_LIMIT_BREACH"),
                                         (6, 0, "ACTUAL_PRICE_LIMIT_BREACH")])
def test_cheap_prior_fill_cannot_hide_later_individual_limit_breach(harness, cost, fee, code):
    cfg, signal, store, ledger, exchange, weather, engine = harness
    assert asyncio.run(engine.execute(signal))
    order = ledger.orders()[0]
    ledger.record_fill(fragment(order, 0, 1_000_000, 1, 0))
    assert ledger.state("fault") is None
    ledger.record_fill(fragment(order, 1, 10, cost, fee))
    assert ledger.state("fault") == code
    assert ledger.summary()["confirmed_fill_count"] == 2
    assert ledger.order(order["id"])["status"] == "CANCEL_REQUESTED"


def build_preexisting_nonconforming_journal(harness):
    cfg, signal, store, ledger, exchange, weather, engine = harness
    assert asyncio.run(engine.execute(signal))
    order = ledger.orders()[0]
    old_path = Path('/workspace/scratch/dea425996b77/frozen-production-review-51d66c9/polymarket_scanner/production/ledger.py')
    spec = importlib.util.spec_from_file_location('polymarket_scanner.production._independent_old_ledger', old_path)
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    previous = old.ExecutionLedger(cfg.execution_db, cfg.wallet)
    # The surrounding current-version harness may have audited its initially
    # empty journal; a journal created by the frozen old release has no marker.
    with previous.transaction() as db:
        db.execute("DELETE FROM execution_state WHERE key='fill_limit_audit_version'")
    rows = [fragment(order, index, 10, 4, 1) for index in range(2)]
    for row in rows:
        previous.record_fill(row)
    assert previous.state("fault") is None
    exchange.fills[order["id"]] = rows
    exchange.remote[order["id"]]["matched"] = 20
    exchange.balances[order["token"]] = 20
    ledger.recover_after_restart()
    return ledger, engine
