# Independent aggregate-limit correction review

Commit: `dfb1a9458eb5f739717fe0d3a5111fb0ca817a8a`.
Tree: `120824c0cd7c0dc43f4795cd7fca89fed901852f`.
Parent: frozen `51d66c9cc42ad9efb23ccd41a6a1ed3972dbe873`.

The nine-line ledger correction addresses newly observed fill fragmentation:
both the individual fill and cumulative order cost/fee are checked against their
respective quantity limits with only one micro-unit aggregate tolerance. Actual
fills, faults and managed cancellation work remain in the same transaction.
Per-fill checks remain necessary because a cheap preceding fill must not hide a
later individually excessive fee/price. Independent adversarial cases verify
that behavior and retry after a cancellation-audit write failure across restart.

Validation: 62 relevant/independent cases passed on Python 3.11. Python 3.12
passed the same 58 fee/lifecycle/previous independent cases and the four new
aggregate cases, run in two invocations. The detached worktree stayed clean.

## Confirmed existing-journal limitation

`repro_preexisting_journal.py` is an intentionally preserved failing requirement
probe, not a waived new-fill test. It uses the real frozen-51 ledger code to
create a synthetic preexisting journal with two individually tolerated fragments
(quantity 10 micros, cost 4 micros, fee 1 micro each). The new ledger then
restarts and receives exactly the same confirmed fills during reconciliation.
`record_fill` returns early for identical previously recorded fills, so the
aggregate violation is never evaluated and `engine.authority()` becomes true.
The reproduction fails the assertion that authority must stay false. All
exchange interactions are isolated mocks; the SQLite journal is temporary.

This is a concrete upgrade-scope limitation. No earlier production journal was
authorized in this project, so the correction can satisfy a fresh first
production-journal scope. An arbitrary preexisting execution journal from older
code cannot be claimed safe without a versioned aggregate audit or explicit
admission exclusion. Unconditional duplicate auditing is not sufficient: it
would repeatedly refault genuine historical breaches already acknowledged by
the local operator. Audit/migration evidence needs an acknowledgement boundary.

Final integrated readiness remains **NOT APPROVED** pending the current public
fee-schema correction and its exact-tree public probe, plus an explicit decision
on the existing-journal scope above.
