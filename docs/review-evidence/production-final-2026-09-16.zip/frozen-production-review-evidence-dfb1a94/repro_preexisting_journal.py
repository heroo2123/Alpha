"""Expected failing scope probe: upgrading a journal written by old bad code.

Not a new-fill regression. No previously deployed production journal is claimed.
"""
import asyncio
from test_independent_aggregate import build_preexisting_nonconforming_journal
from test_production_lifecycle import harness


def test_preexisting_aggregate_breach_is_detected_before_reauthorizing(harness):
    ledger, engine = build_preexisting_nonconforming_journal(harness)
    asyncio.run(engine.reconcile())
    assert not engine.authority(), "Duplicate-only reconciliation admitted a preexisting aggregate breach"
    assert ledger.state("fault") == "ACTUAL_FEE_LIMIT_BREACH"
