"""Adversarial migration/crash/acknowledgement review; isolated journals only."""
import asyncio
from copy import deepcopy

from polymarket_scanner.production.ledger import ExecutionLedger
from test_production_lifecycle import harness
from test_independent_aggregate import build_preexisting_nonconforming_journal, fragment


def test_upgrade_cancel_work_survives_crash_after_marker_before_network(harness):
    cfg, signal, store, _, exchange, weather, engine = harness
    ledger, engine = build_preexisting_nonconforming_journal(harness)
    assert ledger.audit_fill_limits_upgrade()
    oid = ledger.orders()[0]["id"]
    assert exchange.cancels == []
    assert ledger.state("fill_limit_audit_version") == "1"
    engine.ledger = ledger = ExecutionLedger(cfg.execution_db, cfg.wallet)
    ledger.recover_after_restart()
    asyncio.run(engine.tick())
    assert exchange.cancels == [oid]
    assert ledger.order(oid)["status"] == "CANCEL_REQUESTED"
    assert ledger.state("fault") == "ACTUAL_FEE_LIMIT_BREACH"
    assert not engine.authority()
    with ledger.connect() as db:
        assert db.execute("SELECT COUNT(*) FROM execution_audit WHERE kind='FILL_LIMIT_UPGRADE_BREACH'").fetchone()[0] == 1


def test_acknowledged_migration_does_not_disable_limits_for_a_new_late_fill(harness):
    cfg, signal, store, _, exchange, weather, engine = harness
    ledger, engine = build_preexisting_nonconforming_journal(harness)
    asyncio.run(engine.reconcile())
    oid = ledger.orders()[0]["id"]
    exchange.remote[oid]["status"] = "CANCELLED"
    asyncio.run(engine.reconcile(ignore_sticky_fault=True))
    assert engine.reconciled
    ledger.clear_fault("ACTUAL_FEE_LIMIT_BREACH")
    engine.ledger = ledger = ExecutionLedger(cfg.execution_db, cfg.wallet)
    ledger.recover_after_restart()
    asyncio.run(engine.reconcile())
    assert engine.authority()
    second = deepcopy(signal)
    second.update(id="independent-after-upgrade", key="independent-after-upgrade")
    second["legs"][0]["token"] = "124"
    weather.value = second
    assert store.save(second) and store.begin_send(second["id"])
    store.receipt(second["id"], 2)
    assert asyncio.run(engine.execute(second))
    other = exchange.posts[-1]
    assert other != oid
    assert ledger.record_fill(fragment(ledger.order(oid), 2, 10, 4, 1))
    assert ledger.state("fill_limit_audit_version") == "1"
    assert ledger.state("fault") == "ACTUAL_FEE_LIMIT_BREACH"
    assert ledger.order(other)["status"] == "CANCEL_REQUESTED"
    assert ledger.summary()["confirmed_fill_count"] == 3
    assert not engine.authority()
