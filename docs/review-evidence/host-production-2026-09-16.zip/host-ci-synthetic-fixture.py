import os
from pathlib import Path
from types import SimpleNamespace
import pytest

@pytest.fixture(autouse=True)
def synthetic_nonroot_kernel_observations(request, monkeypatch):
    if "host" not in request.fixturenames:
        return
    host = request.getfixturevalue("host")
    proxy = SimpleNamespace(**{key: value for key, value in vars(host.m.os).items() if key != "geteuid"})
    proxy.geteuid = lambda: 1000
    monkeypatch.setattr(host.m, "os", proxy)
    original_stat = Path.lstat
    def fixture_owned(path):
        st = original_stat(path)
        if host.root == path or host.root in path.parents:
            values = list(st)
            values[4] = 1000
            return os.stat_result(values)
        return st
    monkeypatch.setattr(Path, "lstat", fixture_owned)
    original_read = Path.read_text
    def inherited_groups(path, *args, **kwargs):
        value = original_read(path, *args, **kwargs)
        if str(path).startswith("/proc/") and path.name == "status":
            value = "\n".join(row + " 12345" if row.startswith("Groups:") else row for row in value.splitlines()) + "\n"
        return value
    monkeypatch.setattr(Path, "read_text", inherited_groups)
