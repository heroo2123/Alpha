# Independent first correction review

Commit: `acd2c459d6ea848440764365b4844b9767958933`.
Tree: `f12bba80dd86ab2e0752c148dae6dcd4458fa278`.
Preceding rejected freeze: `022c3eaee1fdad90d46fac45a5691fcc2669f3fe`.

Disposition: **NOT APPROVED pending the remaining direct-stop race.**

The original five independent reproductions now pass, together with the five
retained repository regressions: **10 passed on Python 3.12 in 1.11 seconds**.
The delta keeps identity/digest/one-use checks, validates safety acceptance inside
the original expiry interval, treats accepted reductions durably, advances epochs
monotonically, lets safety actions bypass navigation capacity, continues command
polls through UI pressure, and binds financial previews to the displayed revision.
Those are appropriate corrections to the demonstrated cases. Original failure
logs and report remain intact in `../operator-review-evidence-022c3ea`.

One adjacent concrete failure remains in `production/panel.py:246`: a fresh
textual `/stop` obtains a revision to create its action, then obtains settings
again when calling `click` at line 248. If the independent executor publishes an
already accepted SET between those reads, the newly received stop fails
`BUTTON_STATE_CHANGED`, before incrementing safety epoch or recording its request.
Automatic opening authority remains valid. This is not reuse of an old callback;
it is a fresh authenticated emergency text command racing with a normal status
publication.

`test_independent_corrected_controls.py` reproduces that interleaving using the
actual controller dispatch and a mock status publication between the reads.
`adjacent-baseline-312.log/xml` preserve the failing result. Capture one revision
for creation and immediate consumption of this fresh command, or provide a
dedicated atomic authenticated safety path. Existing settings/callback scopes
and one-use state should remain strict.

No source edits, external network calls, host/account actions or broad full-suite
reruns were performed. All effects are temporary databases and mocked peers.
