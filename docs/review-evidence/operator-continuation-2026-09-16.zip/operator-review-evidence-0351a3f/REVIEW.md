# Independent final operator continuation review

Final reviewed commit: `0351a3f10f932c899c9357b7dc2d412ff33dbe6d`.
Final tree: `965ecb0afd7d6cab15e0c62c5e4f06f7184be8b3`.
Continuation baseline: `9552357c9de550c522c60910b4ccb25abd9d9cfd`.
Detached checkout: `../frozen-operator-review-0351a3f` (clean).

**Disposition: PASS for the independent repository/control/credential review
scope. No demonstrated unresolved blocker remains in the final frozen code.**
Final exact-head CI, publication/proposed-merge verification and actual-main
checks remain the parent task's promotion gates. This is not host acceptance,
account acceptance, funding or activation approval.

## Final correction and carried evidence

Independently verified that the final delta from
`89d23f879794a79c28aa932b9cb749ac4f8047c0` contains only the hash-inventory tool,
its four duplicate-spelling regressions and the checkpoint document. Production
code, host authority, both dependency locks and workflows are byte-identical to
that previous reviewed freeze.

The tool now normalizes package-name case and PEP-503 separators before checking
for duplicate keys. The original independent unreviewed-hash reproduction now
rejects, and the repository's case/underscore/dot variants reject as well. The
same normalization applies consistently to expected pins and execution/generated
inventories; exact approved hash-set comparison remains intact.

At this final SHA, **7 hash-focused cases passed on each Python version**:

- Python 3.11: 7 passed, 0.04 seconds.
- Python 3.12: 7 passed, 0.04 seconds.

The canonical inventory tool also confirms all 22 runtime pins and their reviewed
hash sets. The actual locks were independently compared with the original main:
same 22 runtime package/version pins, exactly six additional ABI hashes already
in the unchanged execution lock, and no signing package added to the runtime
lock. That comparison is preserved in the preceding review evidence directory.

Carry forward the **126 focused boundary cases per Python** run against the
unchanged production/host code in `89d23f8` (3.11: 8.40 seconds; 3.12: 8.83
seconds). These include all six independently reproduced operator-control
failures and the affected protocol, executor, panel, scanner handoff,
notifications, grant recovery and three-role host cases. The final tiny
verification-only change did not justify repeating those cases or the root's
full suites.

## Closed independent findings

- Accepted PAUSE/CANCEL requests retain strict identity, integrity and one-use
  receipts, but no longer lose cancellation work because processing occurs
  after a newer revision or the original callback expiry. Acceptance must have
  occurred inside the original validity window; safety epochs advance
  monotonically. Opening/resume/settings/trade requests keep current revision
  and processing-time expiry requirements.
- Preview capacity no longer blocks fresh safety actions, and a full UI reply
  queue no longer aborts the poll before a later stop/cancel command. Safety
  persistence is independent of the reply's eventual delivery.
- Trade/settings preview text and related buttons bind one captured revision.
  A newer permissive setting no longer upgrades a button whose displayed limits
  were lower. Fresh textual stop/cancel creation and consumption also use one
  captured revision, closing the second-read race.
- Canonical-name duplicate detection prevents the new runtime inventory gate
  from hiding a preceding unreviewed hash. The committed lock was never polluted
  by that reproduction; only temporary test copies were modified.

## Scope and limits

The review began at `022c3ea`, tracing actual CLI dispatch and
`production/{control,executor_control,panel,controller,collection,notifications,
engine,ledger,telegram,config,io}.py`, the retained signal/service interactions,
three-role host authority changes, relevant workflows and public measurement
boundaries. It treated the continuation checkpoint, Telegram panel, account
onboarding and UpCloud unfunded commissioning documents as claims to check.
Every subsequent corrective delta was separately read against its exact freeze.

No additional demonstrated protected-ceiling bypass, private-credential escape
or actual-fill/accounting regression was found in that scope. The unchanged
core retains dedicated EOA BUY-to-resolution operation, actual confirmed fill
accounting, sticky faults and reservations, independent activation and local
risk ceilings. EOA full-key custody, unsupported Deposit Wallet/session-key
adapters, absence of automatic selling/redemption, narrow receipt-import scope,
source-finality rejection and incomplete weather-template coverage remain
explicit limitations rather than findings reclassified as completed features.

Host UID/mount/file boundaries, private account eligibility, regional access,
actual test-bot behavior, resource budgets and provider permission remain external
acceptance requirements. This review used only temporary databases, mocked
Telegram/financial peers and local read-only Git/source inspection. It made no
external network, host/service, real account/credential or financial action.

## Preserved evidence

This directory contains `hash-gate-311/312.log` and XML. Earlier reports,
successful focused logs and all original failing reproductions remain in:

- `../operator-review-evidence-022c3ea`: initial rejection, five independent
  failures on both versions, 112 existing focused passes on 3.12.
- `../operator-review-evidence-acd2c45`: original fixes passing, then the
  independently reproduced fresh-stop/status-publication race.
- `../operator-review-evidence-89d23f8`: 126 focused passes per version, clean
  runtime-lock comparison and failing duplicate-hash verifier reproduction.

No earlier failure or conditional disposition was overwritten or relabeled.
