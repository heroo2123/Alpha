# Independent operator continuation review — rejected initial freeze

Reviewed commit: `022c3eaee1fdad90d46fac45a5691fcc2669f3fe`.
Tree: `b73aab3202e3a298f2dd19540e7acfdc45e15d0f`.
Baseline: `9552357c9de550c522c60910b4ccb25abd9d9cfd`.
Detached checkout: `../frozen-operator-review-022c3ea`.

Disposition: **NOT APPROVED. Three demonstrated operator-control blockers.**
This assessment belongs to the stated initial freeze; subsequent fixes require
their own exact-commit assessment. No repository source was edited.

## Findings

### R1 — accepted cancellation can be consumed without cancellation work

`production/control.py:144` rechecks every request against processing-time
expiry and current settings revision/pause epoch. `executor_control.py:124`
handles a mismatch by advancing the consumed request cursor, pausing openings
and explicitly dropping `cancel`, without queuing managed cancellation.

Using actual `Controller.commands` and `OperatorPanel.handle`, send `/stop`
and then `/cancel_open` in the same Telegram update batch with an acknowledged
managed order. Both are accepted and persisted. PAUSE increments the executor's
revision; CANCEL then fails `CONTROL_REVISION_OR_PAUSE_CHANGED`. Its epoch and
receipt are consumed, but the order remains ACKNOWLEDGED and no mocked exchange
cancellation is attempted. This can occur during ordinary rapid operator use,
without malformed payloads or an attacker. A second reproduction delays an
already accepted cancellation by 121 seconds: the dedicated safety loop discards
it as expired. Normal later order expiry/reconciliation is not an execution of
the requested immediate cancellation.

Retain identity/authentication, integrity and one-use checks. Accepted PAUSE and
CANCEL need durable monotonic safety semantics independent of subsequent UI
revisions or processing delay; acceptance must have occurred inside the original
callback validity window. Opening/resume/settings/trade authorizations still
require current revision and expiry.

### R2 — bounded UI state blocks authenticated emergency controls

`control.py:308` applies the 500-PREVIEW cap to PAUSE/CANCEL as well as navigation.
`panel.py:244` creates a preview even for a direct `/stop`. Fill the preview store
with 500 unexpired NAV actions, then dispatch a genuine authorized `/stop`.
The command returns `CONTROL_PREVIEW_CAP` before request/epoch persistence;
automatic opening authority remains valid.

The adjacent reply-queue case also fails: fill the 100-entry UI reply queue and
dispatch `/status`, `/cancel_open` in one poll. `panel.py:69` throws, its error
reply throws again at `panel.py:253`, and `controller.py:45` aborts before the
later cancellation. A slow/unavailable UI path can therefore defer safety
persistence despite the stated independent-loop guarantee. Safety acceptance
must not depend on preview/reply capacity, and one failed UI response must not
starve later safety updates.

### R3 — trade preview silently acquires a newer, more permissive revision

`panel.py:85` reads settings for the preview text, but `panel.py:58` re-reads them
for each newly created action. A separate executor may publish a settings change
between those reads. The reproduction reads a per-order limit of $2, then
processes an already authorized increase to $5 before constructing the buttons.
The user receives text saying `Per-order ceiling $2`, while the opaque confirm
action binds the new $5 revision. The real click, executor validation and tick
accept it and post a mocked order under the higher settings.

This stays within the protected maximum, but violates the narrower limits the
user reviewed for this one attempt. Rendered previews and all associated actions
must use one captured settings/revision snapshot; later changes should make the
button stale rather than silently upgrade it.

## Evidence and scope

`test_independent_controls.py` contains five independent cases: two R1 cases,
two R2 cases, and R3. All five fail on both Python 3.11 and 3.12 against this
exact freeze. `independent-baseline-311/312.log` and XML preserve those failures;
earlier incremental reproduction logs are also retained. Existing focused
protocol/executor/panel/collection/notifications/recovery/three-role host tests
pass: **112 on Python 3.12, 9.49 seconds** (`targeted-existing-312.log/xml`).

Read the continuation checkpoint, Telegram panel, account onboarding and new-host
commissioning documents as claims. Traced `control.py`, `executor_control.py`,
`panel.py`, `controller.py`, `collection.py`, `notifications.py`, CLI dispatch,
Telegram principal checks, configuration parsing, engine/ledger changes and the
three-role host authority delta. Also inspected public measurement/workflow
boundaries and retained production service/signal interactions. The existing
exchange/chain/weather core is unchanged by this continuation.

No additional demonstrated credential escape or protected-ceiling bypass was
found in that scope. Separate UIDs/state directories, role-bound config paths,
credential masks and read-only handoff ownership remain explicit host acceptance
requirements; local unit/fixture tests are not actual target-host attestation.
EOA full-key custody, EOA-only/BUY-only behavior, absence of a session-key adapter,
no automatic selling/redemption and narrow receipt-import support are documented
scope limits, not defects relabeled as blockers. No network, host, account,
credential or Telegram action was performed. All effects used temporary SQLite
stores and mock interfaces. No broad full suite was repeated.
