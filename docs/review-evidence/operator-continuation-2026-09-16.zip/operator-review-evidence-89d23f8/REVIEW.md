# Independent final control-boundary review and hash-gate finding

Commit: `89d23f879794a79c28aa932b9cb749ac4f8047c0`.
Tree: `c50fa49e1eeef5da5a90020d49e22400760e74f8`.
Continuation baseline: `9552357c9de550c522c60910b4ccb25abd9d9cfd`.
Previous correction: `acd2c459d6ea848440764365b4844b9767958933`.

**Control and credential boundary scope: PASS.** All six independently
reproduced dispatch/preview/backlog/safety failures are corrected at this freeze.
**Overall final verification remains pending a narrow hash-inventory gate fix.**
The committed dependency lock itself contains no unreviewed addition.

The fresh textual safety command now captures one revision and uses it both for
action creation and immediate consumption. Its earlier concurrent-status race
now passes. The original five independent cases also pass unchanged, alongside
protocol, executor, UI, scanner handoff, notifications, recovery and three-role
host tests. Independently ran **126 focused cases on each version**:

- Python 3.11: 126 passed, 8.40 seconds.
- Python 3.12: 126 passed, 8.83 seconds.

Evidence is `targeted-controls-311/312.log` and XML. This is the selected
boundary scope, not a redundant full-suite run. Earlier rejected freezes and
their failures remain preserved in the sibling `022c3ea` and `acd2c45` review
directories. The tests use temporary stores and mocked peers only.

## Runtime lock and narrow verifier defect

Independently compared the actual Git blobs against original main: all 22
runtime package/version pins are identical; the execution lock is unchanged.
The six added ABI hashes are already present in that original execution lock.
Every final runtime hash set equals the original execution lock's hash set for
the same runtime pin. `runtime-lock-comparison.json` records the comparison.
The CI delta installs the runtime-only lock into fresh venvs for both supported
Pythons, checks consistency, imports scanner/controller and asserts that
`eth_account` and `eth_abi` are absent. No signing package was added to this lock.

The new `tools/verify_runtime_hash_inventory.py:12` checks duplicate `spec`
against a dictionary whose keys were lowercased at line 14. Consequently a
duplicate mixed-case requirement can overwrite another entry instead of being
rejected. Prepend the existing `PyYAML==6.0.3` row plus an additional `f...f` hash
before the legitimate row: `verify()` returns 22, although the file contains
an unreviewed hash. This is a demonstrated defect in the claimed exact hash-set
rejection gate; it is not a claim that the currently committed lock is polluted.

`test_independent_hash_inventory.py` and `hash-inventory-baseline-312.log/xml`
preserve that failing reproduction. Normalize package identity before duplicate
detection and reject duplicate canonical packages; retain the existing exact
hash-set and pin comparisons. The author has acknowledged this correction.

## Limits

The original review scope remains in force: independent protected configuration
ceilings and activation, one-use trade attempts, retained actual accounting,
separate controller/scanner/executor credentials and state, and explicit host
acceptance. No new concrete credential escape or ceiling bypass was found.
EOA-only full-key custody, BUY-only operation, absent session-key/sell/redemption
adapters and the narrow receipt-import path remain documented limitations.

No external network, actual host, account, Telegram, credential or financial
action was taken. Host mount/UID and fresh dependency installation behavior must
still be established by exact-release CI and separately authorized host
acceptance. This review does not authorize activation or funding.
