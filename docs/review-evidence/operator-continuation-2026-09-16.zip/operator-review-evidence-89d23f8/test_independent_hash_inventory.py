"""Inventory gate must not hide a duplicate requirement's unreviewed hashes."""
from pathlib import Path

import pytest

from tools.verify_runtime_hash_inventory import verify


def test_case_variant_duplicate_cannot_hide_unreviewed_hash(tmp_path):
    root = Path(__import__('tools.verify_runtime_hash_inventory', fromlist=['x']).__file__).resolve().parents[1]
    for name in ('requirements.txt', 'requirements-runtime-hashed.txt', 'requirements-execution-hashed.txt'):
        (tmp_path / name).write_text((root / name).read_text())
    path = tmp_path / 'requirements-runtime-hashed.txt'
    original = path.read_text()
    row = next(line for line in original.splitlines() if line.startswith('PyYAML=='))
    path.write_text(row + ' --hash=sha256:' + 'f' * 64 + '\n' + original)
    with pytest.raises(ValueError):
        verify(tmp_path)
